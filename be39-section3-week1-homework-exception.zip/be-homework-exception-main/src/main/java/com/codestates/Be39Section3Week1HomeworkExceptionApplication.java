package com.codestates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Be39Section3Week1HomeworkExceptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(Be39Section3Week1HomeworkExceptionApplication.class, args);
	}

}
